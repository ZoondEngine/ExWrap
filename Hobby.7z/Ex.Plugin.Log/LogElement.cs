﻿using Ex.Plugin.Log.Behaviours;

using System;
namespace Ex.Plugin.Log
{
    internal class LogElement
    {
        private string m_Element;
        private LogLevel m_Level;

        public LogElement(string element, LogLevel level)
        {
            m_Element = element;
            m_Level = level;
        }

        public string Element()
            => m_Element;
        public LogLevel Level()
            => m_Level;

        public string Stamp()
            => $"[{m_Level.ToString().ToUpper()}]{DateTime.Now:dd/MM/yyyy, HH:mm::ss.f} > {m_Element}" + Environment.NewLine;
    }
}
