﻿using Ex.Attributes;
using Ex.Plugin.Log.Behaviours;

namespace Ex.Plugin.Log
{
    [RequiredBehaviour(typeof(LogWriteBehaviour))]
    public class ExLogObject : ExObject, ILoggableObject
    {
        public ExLogObject()
            : base()
        { }

        public ExLogObject(string tag)
            : base(tag)
        { }

        public LogWriteBehaviour Writer()
            => GetComponent<LogWriteBehaviour>();

        public override void Destroy()
        {
            Writer().BeforeDestroy();
            Writer().Destroy();
        }
    }
}
