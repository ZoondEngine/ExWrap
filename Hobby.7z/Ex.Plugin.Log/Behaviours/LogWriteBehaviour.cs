﻿using Ex.Exceptions;

using System;
using System.Collections.Concurrent;
using System.IO;
using System.Reflection;

namespace Ex.Plugin.Log.Behaviours
{
    public enum LogLevel
    {
        Trace    = 0,
        Warning  = 1,
        Error    = 2,
        Critical = 3
    }

    public class LogWriteBehaviour : ExBehaviour
    {
        private string[] m_Files;
        private ConcurrentQueue<LogElement> m_Queue;
        private bool m_DequeueLocked;

        public void Init(string sublists)
        {
            if(!Directory.Exists("logs"))
            {
                Directory.CreateDirectory( "logs" );
            }

            m_Files = new string[]
           {
                $"logs/{sublists}/debug.exout",
                $"logs/{sublists}/warning.exout",
                $"logs/{sublists}/error.exout",
                $"logs/{sublists}/critical.exout"
           };

            foreach(var path in m_Files)
            {
                var root = Path.GetDirectoryName( path );
                if(!Directory.Exists(root))
                {
                    var info = Directory.CreateDirectory( root );
                    if(!info.Exists)
                    {
                        throw new ExException( $"Can't create directory for path = '{path}'" );
                    }
                }
            }
        }

        public override void Awake()
        {
            m_Queue = new ConcurrentQueue<LogElement>();
        }

        public override void BeforeDestroy()
        {
            foreach ( var item in m_Queue )
                Immediate( item );
        }

        public override void Destroy()
        {
            m_Files = null;
            m_Queue = null;
        }

        public override void Update()
        {
            if(!m_Queue.IsEmpty)
            {
                if(!m_DequeueLocked)
                {
                    if(m_Queue.TryDequeue(out var log))
                    {
                        Immediate( log );
                    }
                }
            }
        }

        public T Parent<T>() where T : ExObject
            => Unbox<T>( ParentObject );

        public void Trace( string what )
            => Queue( new LogElement( what, LogLevel.Trace ) );
        public void Warning( string what )
            => Queue( new LogElement( what, LogLevel.Warning ) );
        public void Error( string what )
            => Queue( new LogElement( what, LogLevel.Error ) );
        public void Critical( string what )
            => Queue( new LogElement( what, LogLevel.Critical ) );

        public void TraceImmediate( string what )
            => Immediate( new LogElement( what, LogLevel.Trace ) );
        public void WarningImmediate( string what )
            => Immediate( new LogElement( what, LogLevel.Warning ) );
        public void ErrorImmediate( string what )
            => Immediate( new LogElement( what, LogLevel.Error ) );
        public void CriticalImmediate( string what )
            => Immediate( new LogElement( what, LogLevel.Critical ) );

        private void Queue( LogElement element )
            => m_Queue.Enqueue( element );

        private void Immediate( LogElement element )
        {
           if(!m_DequeueLocked)
            {
                Switch();

                if(m_Files == null)
                {
                    Init( $"{DateTime.Now.ToShortDateString()}__{Assembly.GetEntryAssembly().GetName().Name}__{Parent<ExObject>().GetType().Name}\\{Parent<ExObject>().GetTag()}" );
                }

                File.AppendAllText( m_Files[ ( int ) element.Level() ], element.Stamp() );

                Switch();
            }
        }

        private void Lock( bool val )
            => m_DequeueLocked = val;
        private void Switch()
            => Lock( !m_DequeueLocked );
    }
}
