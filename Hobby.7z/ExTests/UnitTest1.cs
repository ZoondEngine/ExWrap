﻿using System;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ExTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
