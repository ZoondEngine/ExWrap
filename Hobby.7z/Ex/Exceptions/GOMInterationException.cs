﻿namespace Ex.Exceptions
{
    public class GOMIterationException : ExException
    {
        public GOMIterationException( string message )
            : base( message )
        { }
    }
}
